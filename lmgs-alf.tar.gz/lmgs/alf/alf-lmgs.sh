# Usage: ./alf-lmgs.sh
# Usage: ./alf-lmgs.sh run
# Usage: ./alf-lmgs.sh run areamoleculeqe

if [ -z "$2" ]; then
   label=areamoleculeqe
else
   label=$2
fi

if [ -z "$1" ]; then
   operation=run
else
   operation=$1
fi

list273="0.5 1 1.3 2 2.4 3 4 5 6 6.5 7 7.4 7.5 8 8.8 9 10 11 11.5 11.6 15 20 25 30 35"
list296="0.5 1 1.07 1.3 1.35 2 2.5 3 4 5 5.3 6 6.8 7 7.5 7.7 8 9 9.1 10 11 11.5 11.7 15 20 25 35"

tail=vs-P-$label

for T in 273 296 ; do
  
   head=alf-lmgs-T$T

   if [ "$T" = 273 ]; then
      list=$list273
   elif [ "$T" = 296 ]; then
      list=$list296
   fi
   
   trunk=$head-totalcapacities-$tail

   dat=$trunk.dat
   gcdat=$head-totalgc-$tail.dat
   vcdat=$head-totalvc-$tail.dat
   usablegcdat=$head-usablegc-$tail.dat
   usablevcdat=$head-usablevc-$tail.dat
   testsdat=$trunk-tests.dat

   datnew=$dat-new
   gcdatnew=$gcdat-new
   vcdatnew=$vcdat-new
   usablegcdatnew=$usablegcdat-new
   usablevcdatnew=$usablevcdat-new
   testsdatnew=$testsdat-new

   rm -f $datnew $gcdatnew $vcdatnew $usablegcdatnew $usablevcdatnew
   rm -f $testsdatnew

   echo "#P T totalgc totalvc usablegc usablevc" > $datnew
   echo "#(MPa) (K) (wt.%) (kg/L) (wt.%) (kg/L)" >> $datnew

   for P in $list ; do
      cp -fp alf-lmgs-generic-$label.input temp.input
      replace.sh Pressure $P temp.input
      replace.sh Temperature $T temp.input
      $HOME/bin/lmgs/lmgs < temp.input >> $datnew
      rm -f temp.input
      cat tests.dat >> $testsdatnew
      rm -f tests.dat
   done

   awk '{print $1,$3}' $datnew > $gcdatnew
   awk '{print $1,$4}' $datnew > $vcdatnew
   awk '{print $1,$5}' $datnew > $usablegcdatnew
   awk '{print $1,$6}' $datnew > $usablevcdatnew

   echo Comparisons $T

   for a in $dat $gcdat $vcdat $usablegcdat $usablevcdat $testsdat ; do
      columnate.sh $a-new
      chmod 600 $a-new
      echo $a
      diff $a-new $a
      if [ $operation = move ]; then
         mv -f $a-new $a
      fi
   done

done

function minreal(a,b)
implicit none
! Parameters
include 'precision.inc'
! Function value
real(DOUBLE) :: minreal
! Function arguments
real(DOUBLE), intent(in) :: a,b

if (a<b) then
   minreal=a
else
   minreal=b
end if

end function minreal

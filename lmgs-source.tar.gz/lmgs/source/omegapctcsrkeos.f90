subroutine omegapctcsrkeos(symbolgas,omega,Pc,Tc)
implicit none
! Parameters
include 'precision.inc'
! Subroutine arguments
character(3), intent(in) :: symbolgas
real(DOUBLE), intent(inout) :: omega,Pc,Tc

if (symbolgas=='H2') then
   ! The values of omega, Pc and Tc for hydrogen gas were taken from:
   ! Determination of compressibility factor and fugacity coefficient of hydrogen in studies 
   ! of adsorptive storage. Li Zhou and Yaping Zhou. IJHE vol. 26, pages 597-601 (2001)
   omega=-0.216_DOUBLE
   Pc=1.28_DOUBLE ! MPa
   Tc=33.2_DOUBLE ! K
else if (symbolgas=='CH4') then
   ! The values of omega, Pc and Tc for methane, CO2 and N2 gases were taken from:
   ! Crossover Volume Translation Soave−Redlich−Kwong Equation of State for Fluids
   ! Xin-Hao Xu, Yuan-Yuan Duan and Zhen Yang. Ind. Eng. Chem. Res. 2012, 51, 6580-6585
   ! The authors of the above paper took the values of the parameters of the gases
   ! from: NIST Chemistry Webbook. http://webbook.nist.gov/chemistry
   omega=0.01142_DOUBLE
   Pc=4.5992_DOUBLE ! MPa
   Tc=190.56_DOUBLE ! K
else if (symbolgas=='CO2') then
   omega=0.22394_DOUBLE
   Pc=7.3773_DOUBLE ! MPa
   Tc=304.13_DOUBLE ! K
else if (symbolgas=='N2') then
   omega=0.0372_DOUBLE
   Pc=3.3958_DOUBLE ! MPa
   Tc=126.19_DOUBLE ! K
end if

end subroutine omegapctcsrkeos

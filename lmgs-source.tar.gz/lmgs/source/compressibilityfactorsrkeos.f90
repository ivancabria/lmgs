! This function calculates the compressibility factor Z of the SRK equation of state
! by solving the equation of the compressibility factor Z of the SRK equation of
! state:       Z^3 - Z^2 + Z(A-B-B*B) - AB = 0
 
! The above equation was taken from:
! Equilibrium constants from a modified Redlich-Kwong equation of state. Giorgio
! Soave. Chemical Engineering Science, 1972, Vol. 27, pp. 1197-1203.

function compressibilityfactorsrkeos(printoption,P,T,A,B)
implicit none
! Parameters
include 'precision.inc'
! Function value
real(DOUBLE) :: compressibilityfactorsrkeos ! dimensionless
! Function arguments
integer, intent(in) :: printoption
real(DOUBLE), intent(in) :: P,T,A,B
! Local variables
integer :: i,j,trace,firm
real(DOUBLE) :: a3,a2,a1,a0,max12,min12,r(2)
complex(DOUBLE) :: root(3)
character(3) :: istop
! Functions
real(DOUBLE) :: maxreal,minreal

trace=0
firm=0
root=(0.0_DOUBLE,0.0_DOUBLE)
istop='yes'

! The compressibility factor Z of the SRK equation is obtained by solving this equation:
! Z^3 - Z^2 + Z(A-B-B*B) - AB = 0
! The compressibility factor Z should be > 0

a3=1.0_DOUBLE
a2=-1.0_DOUBLE
a1=A-B-B*B
a0=-A*B

call rootsthirddegreepolynom(a3,a2,a1,a0,trace,firm,root)

if (firm==-4) then ! Two roots are complex
   compressibilityfactorsrkeos=real(root(1)) ! root(1) is the real root
   istop='no'

   if (printoption==1) then
      do i=1,3
         write(*,100) i,real(root(i)),aimag(root(i))
      end do
   end if
   if (printoption==1) write(*,110) firm,compressibilityfactorsrkeos,P,T
else if (firm==-1) then ! The three roots are real and only one root is positive
!  The compressibility factor z should be > 0. Hence, the positive root is the 
!  compressibility factor z
   if (real(root(1))>=0.0_DOUBLE) then
      compressibilityfactorsrkeos=real(root(1))
   else if (real(root(2))>=0.0_DOUBLE) then
      compressibilityfactorsrkeos=real(root(2))
   else if (real(root(3))>=0.0_DOUBLE) then
      compressibilityfactorsrkeos=real(root(3))
   end if
   istop='no'

   if (printoption==1) then
      do i=1,3
         write(*,100) i,real(root(i)),aimag(root(i))
      end do
   end if
   if (printoption==1) write(*,110) firm,compressibilityfactorsrkeos,P,T
else if (firm==3) then ! The three roots are real and positive
   ! If firm==3, then the correct root for gases depends on the values of P and T
   ! If P,T are in the range of the ideal gas, then the root is the largest (and
   ! closest to one)
   ! If P,T are far from the range of the ideal gas, then the root is the smallest one (and 
   ! closest to zero)
   if (P<1.0E-3_DOUBLE .or. T>250.0_DOUBLE) then ! Ideal gas behaviour
      max12=maxreal(real(root(1)),real(root(2)))
      compressibilityfactorsrkeos=maxreal(max12,real(root(3)))
   else
      min12=minreal(real(root(1)),real(root(2)))
      compressibilityfactorsrkeos=minreal(min12,real(root(3)))
   end if
   istop='no'

   do i=1,3
      write(*,100) i,real(root(i)),aimag(root(i))
   end do
   write(*,110) firm,compressibilityfactorsrkeos,P,T
   write(*,120) firm
else if (firm==1) then ! Two roots are real and positive and one is real and negative
   ! If firm==1, then the correct root for gases depends on the values of P and T
   ! If P,T are in the range of the ideal gas, then the root is the largest (and
   ! closest to one)
   ! If P,T are far from the range of the ideal gas, then the root is the smallest one (and 
   ! closest to zero)
   r=0.0_DOUBLE
   j=0
   do i=1,3
      if (real(root(i)) >= 0.0_DOUBLE .and. j<2) then
         j=j+1
         r(j)=real(root(i))
      end if
   end do
   if (P<1.0E-3_DOUBLE .or. T>250.0_DOUBLE) then ! Ideal gas behaviour
      compressibilityfactorsrkeos=maxreal(r(1),r(2))
   else
      compressibilityfactorsrkeos=minreal(r(1),r(2))
   end if
   istop='no'

   do i=1,3
      write(*,100) i,real(root(i)),aimag(root(i))
   end do
   write(*,110) firm,compressibilityfactorsrkeos,P,T
   write(*,120) firm
else
   compressibilityfactorsrkeos=0.0_DOUBLE
   istop='yes'

   do i=1,3
      write(*,100) i,real(root(i)),aimag(root(i))
   end do
   write(*,*) 'firm=',firm
   write(*,*) 'Firm is the difference between the number of real positive roots and the number of real negative roots.'
   write(*,*) 'Firm=-4 means that two roots are complex.'
   write(*,*) 'Firm should be -4, -1, 1 or 3'
end if

call continueorstop(istop)

100 format('Test root(',i1,')=',f19.14,1x,f19.14)
110 format('Test firm=',i2,' z=',f19.14,' P=',f19.14,' T=',f19.14)
120 format('Warning: Firm=',i2,'. Check the results.')

end function compressibilityfactorsrkeos

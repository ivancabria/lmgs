subroutine langmuirtotalcapacities(nsites,langmuirmaxnmolecules,&
volumesimulationcell,massmaterial,P,T,bindingenergyineV,quotient,symbolgas,&
massh2,totalgc,totalvc,langmuirnumberofmolecules)
implicit none
! Parameters
include 'precision.inc'
include 'masses.inc'
include 'avogadro.inc'
include 'evsrydberg.inc'
! Subroutine arguments
integer, intent(in) :: nsites
real(DOUBLE), intent(in) :: langmuirmaxnmolecules
real(DOUBLE), intent(in) :: volumesimulationcell
real(DOUBLE), intent(in) :: massmaterial ! kg
real(DOUBLE), intent(in) :: P ! the pressure in MPa
real(DOUBLE), intent(in) :: T ! the temperature in K
real(DOUBLE), intent(in) :: bindingenergyineV(5) ! eV/molecule
real(DOUBLE), intent(in) :: quotient(5)
character(3), intent(in) :: symbolgas
real(DOUBLE), intent(inout) :: massh2 ! kg
real(DOUBLE), intent(inout) :: totalgc ! wt. %
real(DOUBLE), intent(inout) :: totalvc ! kg/L
real(DOUBLE), intent(inout) :: langmuirnumberofmolecules
! Local variables
integer :: i
real(DOUBLE) :: bindingenergy(5) ! rydberg/molecule
character(30) :: units
! Functions
! langmuirnmolecules: Number of molecules, according to the Langmuir model
real(DOUBLE) :: langmuirnmolecules
! langmuirnmoleculessite(i): Number of molecules on site i, according to the 
! Langmuir model
real(DOUBLE) :: langmuirnmoleculessite(5) 
real(DOUBLE) :: massmolecule

langmuirnumberofmolecules=0.0_DOUBLE
massh2=0.0_DOUBLE ! kg
bindingenergy=0.0_DOUBLE ! rydberg/molecule

do i=1,nsites
   bindingenergy(i)=bindingenergyineV(i)/EVSRYDBERG ! rydberg/molecule
   langmuirnmoleculessite(i)=quotient(i)*langmuirnmolecules(bindingenergy(i),&
   langmuirmaxnmolecules,P,T,symbolgas)
end do

langmuirnumberofmolecules=0.0_DOUBLE
do i=1,nsites
   langmuirnumberofmolecules=langmuirnumberofmolecules + &
   langmuirnmoleculessite(i)
end do

units='kg'
massh2=langmuirnumberofmolecules*massmolecule(symbolgas,units) ! kg

! Calculation of the total storage capacities
totalgc=100.0_DOUBLE * massh2/(massh2 + massmaterial) ! wt. %
totalvc=massh2/(volumesimulationcell*1.0E-27_DOUBLE) ! kg/L

end subroutine langmuirtotalcapacities

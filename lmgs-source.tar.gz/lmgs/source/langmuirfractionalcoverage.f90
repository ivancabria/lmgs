! The Langmuir fractional coverage or Langmuir equation is:

! fraction = 1 / ( 1 + exp(a) )    a=(Eb-mu)*beta
! Eb: binding energy. It has a negative value
! mu=mu(P,T): chemical potential at P and T

! This function implements that function

! The Langmuir fractional coverage is derived from the Grand Canonical ensemble 
! The derivation and the equation can be found in:

! Terrell L. Hill,
! Statistical Mechanics: Principles and Selected Applications,
! McGraw--Hill, 1956, New York

! Masatsugu Sei Suzuki,
! Langmuir adsorption: application of grand canonical ensemble,
! Department of Physics, SUNY at Binghamton, 2023,
! https://bingweb.binghamton.edu/~suzuki/ThermoStatFIles/7.7\%20GCE\%20Langmuir\%20adsorption.pdf

! Cersonsky Lab,
! Application of independent subsystems: the Langmuir isotherm,
! https://cersonsky-lab.github.io/cbe710-notes/lecture_files/Lecture7.html,
! 2023,
! Advanced Thermodynamics for Chemical Engineers, lecture notes



! bindingenergy in rydberg
! P is the pressure in MPa
! T is the temperature in K

function langmuirfractionalcoverage(bindingenergy,P,T,symbolgas)
implicit none
! Parameters
include 'precision.inc'
include 'kb.inc'
include 'evshartree.inc'
include 'joulesev.inc'
include 'kbinjoulesperk.inc'
! Function value
real(DOUBLE) :: langmuirfractionalcoverage
! Function arguments
real(DOUBLE), intent(in) :: bindingenergy ! rydberg/molecule
real(DOUBLE), intent(in) :: P ! MPa
real(DOUBLE), intent(in) :: T ! K
character(3), intent(in) :: symbolgas
! Local variables
real(DOUBLE) :: mu,beta,a
!real(DOUBLE) :: betainSIunits,lambdainSIunits,P0inSIunits,lambda,P0
! Functions
real(DOUBLE) :: chemicalpotentialsrkeos ! rydberg/molecule
!real(DOUBLE) :: thermaldeBrogliewavelength ! angstroms

!betainSIunits=1.0_DOUBLE/(KBINJOULESPERK*T) ! joules^-1
!lambda=thermaldeBrogliewavelength(T,symbolgas) ! angstrom
!lambdainSIunits=lambda*1.0E-10_DOUBLE ! m
!beta=1.0_DOUBLE/(KB*2.0_DOUBLE*T) ! rydberg^-1
!P0inSIunits=exp(beta*bindingenergy)/(betainSIunits*lambdainSIunits*lambdainSIunits*lambdainSIunits) ! Pa
!P0=P0inSIunits/1.0E+6_DOUBLE ! MPa
!langmuirfractionalcoverage = P / ( P + P0 ) ! dimensionless

mu=chemicalpotentialsrkeos(P,T,symbolgas) ! rydbergs/molecule
beta=1.0_DOUBLE/(KB*2.0_DOUBLE*T) ! rydberg^-1
a=(bindingenergy - mu)*beta ! dimensionless
langmuirfractionalcoverage = 1.0_DOUBLE / ( 1.0_DOUBLE + exp(a) ) ! dimensionless

end function langmuirfractionalcoverage

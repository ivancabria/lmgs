function atomicnumber(symbol)
implicit none
! Function value
integer :: atomicnumber
! Function arguments
character(3), intent(in) :: symbol

if (symbol.eq.'H') then
   atomicnumber=1
else if (symbol.eq.'He') then
   atomicnumber=2
else if (symbol.eq.'Li') then
   atomicnumber=3
else if (symbol.eq.'Be') then
   atomicnumber=4
else if (symbol.eq.'B') then
   atomicnumber=5
else if (symbol.eq.'C') then
   atomicnumber=6
else if (symbol.eq.'N') then
   atomicnumber=7
else if (symbol.eq.'O') then
   atomicnumber=8
else if (symbol.eq.'F') then
   atomicnumber=9
else if (symbol.eq.'Ne') then
   atomicnumber=10
else if (symbol.eq.'Na') then
   atomicnumber=11
else if (symbol.eq.'Mg') then
   atomicnumber=12
else if (symbol.eq.'Al') then
   atomicnumber=13
else if (symbol.eq.'Si') then
   atomicnumber=14
else if (symbol.eq.'P') then
   atomicnumber=15
else if (symbol.eq.'S') then
   atomicnumber=16
else if (symbol.eq.'Cl') then
   atomicnumber=17
else if (symbol.eq.'Ar') then
   atomicnumber=18
else if (symbol.eq.'K') then
   atomicnumber=19
else if (symbol.eq.'Ca') then
   atomicnumber=20
else if (symbol.eq.'Sc') then 
  atomicnumber=21
else if (symbol.eq.'Ti') then
   atomicnumber=22
else if (symbol.eq.'V') then
   atomicnumber=23
else if (symbol.eq.'Cr') then
   atomicnumber=24
else if (symbol.eq.'Mn') then
   atomicnumber=25
else if (symbol.eq.'Fe') then
   atomicnumber=26
else if (symbol.eq.'Co') then
   atomicnumber=27
else if (symbol.eq.'Ni') then
   atomicnumber=28
else if (symbol.eq.'Cu') then
   atomicnumber=29
else if (symbol.eq.'Zn') then
   atomicnumber=30
else if (symbol.eq.'Ga') then
   atomicnumber=31
else if (symbol.eq.'Ge') then
   atomicnumber=32
else if (symbol.eq.'As') then
   atomicnumber=33
else if (symbol.eq.'Se') then
   atomicnumber=34
else if (symbol.eq.'Br') then
   atomicnumber=35
else if (symbol.eq.'Kr') then
   atomicnumber=36
else if (symbol.eq.'Rb') then 
   atomicnumber=37
else if (symbol.eq.'Sr') then 
   atomicnumber=38
else if (symbol.eq.'Y') then
   atomicnumber=39
else if (symbol.eq.'Zr') then
   atomicnumber=40
else if (symbol.eq.'Nb') then
   atomicnumber=41
else if (symbol.eq.'Mo') then
   atomicnumber=42
else if (symbol.eq.'Tc') then
   atomicnumber=43
else if (symbol.eq.'Ru') then
   atomicnumber=44
else if (symbol.eq.'Rh') then
   atomicnumber=45
else if (symbol.eq.'Pd') then
   atomicnumber=46
else if (symbol.eq.'Ag') then
   atomicnumber=47
else if (symbol.eq.'Cd') then
   atomicnumber=48
else if (symbol.eq.'In') then
   atomicnumber=49
else if (symbol.eq.'Sn') then 
   atomicnumber=50
else if (symbol.eq.'Sb') then
   atomicnumber=51
else if (symbol.eq.'Te') then
   atomicnumber=52
else if (symbol.eq.'I') then
   atomicnumber=53
else if (symbol.eq.'Xe') then
   atomicnumber=54
else if (symbol.eq.'Cs') then
   atomicnumber=55
else if (symbol.eq.'Ba') then
   atomicnumber=56
else if (symbol.eq.'La') then
   atomicnumber=57
else if (symbol.eq.'Ce') then
   atomicnumber=58
else if (symbol.eq.'Pr') then
   atomicnumber=59
else if (symbol.eq.'Nd') then 
   atomicnumber=60
else if (symbol.eq.'Pm') then
   atomicnumber=61
else if (symbol.eq.'Sm') then
   atomicnumber=62
else if (symbol.eq.'Eu') then
   atomicnumber=63
else if (symbol.eq.'Gd') then
   atomicnumber=64
else if (symbol.eq.'Tb') then
   atomicnumber=65
else if (symbol.eq.'Dy') then
   atomicnumber=66
else if (symbol.eq.'Ho') then
   atomicnumber=67
else if (symbol.eq.'Er') then
   atomicnumber=68
else if (symbol.eq.'Tm') then
   atomicnumber=69
else if (symbol.eq.'Yb') then
   atomicnumber=70
else if (symbol.eq.'Lu') then
   atomicnumber=71
else if (symbol.eq.'Hf') then
   atomicnumber=72
else if (symbol.eq.'Ta') then
   atomicnumber=73
else if (symbol.eq.'W') then
   atomicnumber=74
else if (symbol.eq.'Re') then
   atomicnumber=75
else if (symbol.eq.'Os') then
   atomicnumber=76
else if (symbol.eq.'Ir') then
   atomicnumber=77
else if (symbol.eq.'Pt') then 
  atomicnumber=78
else if (symbol.eq.'Au') then
   atomicnumber=79
else if (symbol.eq.'Hg') then
   atomicnumber=80
else if (symbol.eq.'Tl') then
   atomicnumber=81
else if (symbol.eq.'Pb') then
   atomicnumber=82
else if (symbol.eq.'Bi') then
   atomicnumber=83
else if (symbol.eq.'Po') then
   atomicnumber=84
else if (symbol.eq.'At') then
   atomicnumber=85
else if (symbol.eq.'Rn') then
   atomicnumber=86
else if (symbol.eq.'Fr') then
   atomicnumber=87
else if (symbol.eq.'Ra') then
   atomicnumber=88
else if (symbol.eq.'Ac') then
   atomicnumber=89
else if (symbol.eq.'Th') then
   atomicnumber=90
else if (symbol.eq.'Pa') then
   atomicnumber=91
else if (symbol.eq.'U') then
   atomicnumber=92
else if (symbol.eq.'Np') then
   atomicnumber=93
else if (symbol.eq.'Pu') then
   atomicnumber=94
else if (symbol.eq.'Am') then
   atomicnumber=95
else if (symbol.eq.'Cm') then
   atomicnumber=96
else if (symbol.eq.'Bk') then
   atomicnumber=97
else if (symbol.eq.'Cf') then
   atomicnumber=98
else if (symbol.eq.'Es') then
   atomicnumber=99
else if (symbol.eq.'Fm') then
   atomicnumber=100
else if (symbol.eq.'Md') then
   atomicnumber=101
else if (symbol.eq.'No') then
   atomicnumber=102
else if (symbol.eq.'Lr') then
   atomicnumber=103
else if (symbol.eq.'H2') then
   atomicnumber=201 ! In the future, this should be 104
else if (symbol.eq.'H2O') then
   atomicnumber=202 ! In the future, this should be 105
else if (symbol.eq.'CH4') then
   atomicnumber=203 ! In the future, this should be 106
else if (symbol.eq.'N2') then
   atomicnumber=204 ! In the future, this should be 107
else if (symbol.eq.'CO2') then
   atomicnumber=205 ! In the future, this should be 108
else
   atomicnumber=0
end if

end function atomicnumber

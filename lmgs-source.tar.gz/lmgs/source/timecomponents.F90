subroutine timecomponents(time_array,year,dayc,hourc,minutec,secondc,month3c,yearc)
implicit none
! Parameters
include 'precision.inc'
! Subroutine arguments
integer, intent(inout) :: time_array(8),year
character(2), intent(inout) :: dayc,hourc,minutec,secondc
character(3), intent(inout) :: month3c
character(4), intent(inout) :: yearc
! Local variables
character(2) :: monthc
character(8) :: datec
character(10) :: timec

! datec, dayc, monthc and yearc are character variables
call date_and_time(date=datec,time=timec,values=time_array)

yearc=datec(1:4)
monthc=datec(5:6)
dayc=datec(7:8)
hourc=timec(1:2)
minutec=timec(3:4)
secondc=timec(5:6)

if (monthc.eq.'01') month3c='Jan'
if (monthc.eq.'02') month3c='Feb'
if (monthc.eq.'03') month3c='Mar'
if (monthc.eq.'04') month3c='Apr'
if (monthc.eq.'05') month3c='May'
if (monthc.eq.'06') month3c='Jun'
if (monthc.eq.'07') month3c='Jul'
if (monthc.eq.'08') month3c='Aug'
if (monthc.eq.'09') month3c='Sep'
if (monthc.eq.'10') month3c='Oct'
if (monthc.eq.'11') month3c='Nov'
if (monthc.eq.'12') month3c='Dec'

year=time_array(1)

end subroutine timecomponents

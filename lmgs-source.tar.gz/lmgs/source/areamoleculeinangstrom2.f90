function areamoleculeinangstrom2(symbolgas)
implicit none
! Parameters
include 'precision.inc'
! Function value
real(DOUBLE) :: areamoleculeinangstrom2 ! angstrom2
! Function arguments
character(3), intent(in) :: symbolgas
! Functions
real(DOUBLE) :: averagedistancebetweenmolecules ! angstrom

! In a hexagonal close packed structure, the area covered by one molecule is
! sqrt(3)*d*d/2, where d is the average distance between the molecules
areamoleculeinangstrom2 = sqrt(3.0_DOUBLE)*0.5_DOUBLE*&
averagedistancebetweenmolecules(symbolgas)*&
averagedistancebetweenmolecules(symbolgas)

end function areamoleculeinangstrom2

! Mass of a molecule in the corresponding units

function massmolecule(symbol,units)
implicit none
! Parameters
include 'precision.inc'
include 'masselectroninamus.inc'
include 'amusperkg.inc'
! Function value
real(DOUBLE) :: massmolecule
! Function arguments
character(3), intent(in) :: symbol
character(30), intent(in) :: units
! Local variables
integer :: j
! Functions
integer :: atomicnumber
real(DOUBLE) :: massinusvsidnumber

j=atomicnumber(symbol)

if (units=='u') then
   massmolecule=massinusvsidnumber(j) ! u units
else if (units=='atomicunitsofmass') then
   massmolecule=massinusvsidnumber(j)/MASSELECTRONINAMUS ! atomic units of mass
else if (units=='kg') then
   massmolecule=massinusvsidnumber(j)/AMUSPERKG ! kg
else
   massmolecule=0.0_DOUBLE
end if

end function massmolecule

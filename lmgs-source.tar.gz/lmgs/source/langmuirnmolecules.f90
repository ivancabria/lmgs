! bindingenergy in rydberg
! langmuirmaxnmolecules: Maximum number of molecules, according to the Langmuir model
! langmuirmaxnmolecules is a real number, not an integer number
! P is the pressure in MPa
! T is the temperature in K

function langmuirnmolecules(bindingenergy,langmuirmaxnmolecules,P,T,symbolgas)
implicit none
! Parameters
include 'precision.inc'
! Function value
real(DOUBLE) :: langmuirnmolecules ! Number of molecules, according to the Langmuir model
! Function arguments
real(DOUBLE), intent(in) :: bindingenergy,langmuirmaxnmolecules,P,T
character(3), intent(in) :: symbolgas
! Functions
real(DOUBLE) :: langmuirfractionalcoverage

langmuirnmolecules = langmuirmaxnmolecules*&
langmuirfractionalcoverage(bindingenergy,P,T,symbolgas)

end function langmuirnmolecules

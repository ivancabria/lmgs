function hostname()
implicit none
! Parameters
include 'precision.inc'
! Function value
character(32) :: hostname
! Local variables
integer :: ihostname
! Function
#ifdef ppc64
integer :: hostnm_
#else
integer :: hostnm
#endif

#ifdef ppc64
ihostname = hostnm_(hostname)
#else
ihostname = hostnm(hostname)
#endif

end function hostname

! logfugacitycoefficientsrkeos is dimensionless

! logfugacitycoefficientsrkeos = log(fi)

! log(fi) is a function of P and T
! fi is the fugacity coefficient; fi = f/P; f is the fugacity
! P is the pressure in MPa
! T is the temperature in K

! The values of the parameters and all the equations, Z and log(fi), were taken from:
! Equilibrium constants from a modified Redlich-Kwong equation of state. Giorgio
! Soave. Chemical Engineering Science, 1972, Vol. 27, pp. 1197-1203.

function logfugacitycoefficientsrkeos(P,T,symbolgas)
implicit none
! Parameters
include 'precision.inc'
! Function value
real(DOUBLE) :: logfugacitycoefficientsrkeos ! dimensionless
! Function arguments
real(DOUBLE), intent(in) :: P,T
character(3), intent(in) :: symbolgas
! Local variables
real(DOUBLE) :: A,B,Z
! Functions
real(DOUBLE) :: compressibilityfactorsrkeos

call abparameterssrkeos(P,T,symbolgas,A,B)

Z=compressibilityfactorsrkeos(0,P,T,A,B)

logfugacitycoefficientsrkeos = Z - 1.0_DOUBLE - log(Z-B) - (A/B)*log(1.0_DOUBLE + (B/Z)) ! dimensionless

end function logfugacitycoefficientsrkeos

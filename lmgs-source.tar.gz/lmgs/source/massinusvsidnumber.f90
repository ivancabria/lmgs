function massinusvsidnumber(i)
implicit none
include 'precision.inc'
! Function value
real(DOUBLE) :: massinusvsidnumber
! Function arguments
integer, intent(in) :: i

if (i==1) then
   massinusvsidnumber=1.00794_DOUBLE
else if (i==2) then
   massinusvsidnumber=4.002602_DOUBLE
else if (i==3) then
   massinusvsidnumber=6.94_DOUBLE
else if (i==4) then
   massinusvsidnumber=9.0121831_DOUBLE
else if (i==5) then
   massinusvsidnumber=10.81_DOUBLE
else if (i==6) then
   massinusvsidnumber=12.0_DOUBLE
!  massinusvsidnumber=12.011
else if (i==7) then
   massinusvsidnumber=14.007_DOUBLE
else if (i==8) then
   massinusvsidnumber=15.999_DOUBLE
else if (i==9) then
   massinusvsidnumber=18.998403163_DOUBLE
else if (i==10) then
   massinusvsidnumber=20.1797_DOUBLE
else if (i==11) then
   massinusvsidnumber=22.98976928_DOUBLE
else if (i==12) then
   massinusvsidnumber=24.305_DOUBLE
else if (i==13) then
   massinusvsidnumber=26.9815385_DOUBLE
else if (i==14) then
   massinusvsidnumber=28.085_DOUBLE
else if (i==15) then
   massinusvsidnumber=30.973761998_DOUBLE
else if (i==16) then
   massinusvsidnumber=32.06_DOUBLE
else if (i==17) then
   massinusvsidnumber=35.45_DOUBLE
else if (i==18) then
   massinusvsidnumber=39.948_DOUBLE
else if (i==19) then
   massinusvsidnumber=39.0983_DOUBLE
else if (i==20) then
   massinusvsidnumber=40.078_DOUBLE
else if (i==21) then
  massinusvsidnumber=44.955908_DOUBLE
else if (i==22) then
   massinusvsidnumber=47.867_DOUBLE
else if (i==23) then
   massinusvsidnumber=50.9415_DOUBLE
else if (i==24) then
   massinusvsidnumber=51.9961_DOUBLE
else if (i==25) then
   massinusvsidnumber=54.938044_DOUBLE
else if (i==26) then
   massinusvsidnumber=55.845_DOUBLE
else if (i==27) then
   massinusvsidnumber=58.933194_DOUBLE
else if (i==28) then
   massinusvsidnumber=58.6934_DOUBLE
else if (i==29) then
   massinusvsidnumber=63.546_DOUBLE
else if (i==30) then
   massinusvsidnumber=65.38_DOUBLE
else if (i==31) then
   massinusvsidnumber=69.723_DOUBLE
else if (i==32) then
   massinusvsidnumber=72.630_DOUBLE
else if (i==33) then
   massinusvsidnumber=74.921595_DOUBLE
else if (i==34) then
   massinusvsidnumber=78.971_DOUBLE
else if (i==35) then
   massinusvsidnumber=79.904_DOUBLE
else if (i==36) then
   massinusvsidnumber=83.798_DOUBLE
else if (i==37) then
   massinusvsidnumber=85.4678_DOUBLE
else if (i==38) then
   massinusvsidnumber=87.62_DOUBLE
else if (i==39) then
   massinusvsidnumber=88.90584_DOUBLE
else if (i==40) then
   massinusvsidnumber=91.224_DOUBLE
else if (i==41) then
   massinusvsidnumber=92.90637_DOUBLE
else if (i==42) then
   massinusvsidnumber=95.95_DOUBLE
else if (i==43) then
   massinusvsidnumber=98.0_DOUBLE
else if (i==44) then
   massinusvsidnumber=101.07_DOUBLE
else if (i==45) then
   massinusvsidnumber=102.90550_DOUBLE
else if (i==46) then
   massinusvsidnumber=106.42_DOUBLE
else if (i==47) then
   massinusvsidnumber=107.8682_DOUBLE
else if (i==48) then
   massinusvsidnumber=112.414_DOUBLE
else if (i==49) then
   massinusvsidnumber=114.818_DOUBLE
else if (i==50) then
   massinusvsidnumber=118.710_DOUBLE
else if (i==51) then
   massinusvsidnumber=121.760_DOUBLE
else if (i==52) then
   massinusvsidnumber=127.60_DOUBLE
else if (i==53) then
   massinusvsidnumber=126.90447_DOUBLE
else if (i==54) then
   massinusvsidnumber=131.293
else if (i==55) then
   massinusvsidnumber=132.90545196
else if (i==56) then
   massinusvsidnumber=137.327
else if (i==57) then
   massinusvsidnumber=138.90547
else if (i==58) then
   massinusvsidnumber=140.116
else if (i==59) then
   massinusvsidnumber=140.90766
else if (i==60) then
   massinusvsidnumber=144.242
else if (i==61) then
   massinusvsidnumber=145.0
else if (i==62) then
   massinusvsidnumber=150.36
else if (i==63) then
   massinusvsidnumber=151.964
else if (i==64) then
   massinusvsidnumber=157.25
else if (i==65) then
   massinusvsidnumber=158.92535
else if (i==66) then
   massinusvsidnumber=162.500
else if (i==67) then
   massinusvsidnumber=164.93033
else if (i==68) then
   massinusvsidnumber=167.259
else if (i==69) then
   massinusvsidnumber=168.93422
else if (i==70) then
   massinusvsidnumber=173.054
else if (i==71) then
   massinusvsidnumber=174.9668
else if (i==72) then
   massinusvsidnumber=178.49
else if (i==73) then
   massinusvsidnumber=180.94788
else if (i==74) then
   massinusvsidnumber=183.84
else if (i==75) then
   massinusvsidnumber=186.207
else if (i==76) then
   massinusvsidnumber=190.23
else if (i==77) then
   massinusvsidnumber=192.217
else if (i==78) then
   massinusvsidnumber=195.084
else if (i==79) then
   massinusvsidnumber=196.966569
else if (i==80) then
   massinusvsidnumber=200.592
else if (i==81) then
   massinusvsidnumber=204.38
else if (i==82) then
   massinusvsidnumber=207.2
else if (i==83) then
   massinusvsidnumber=208.98040
else if (i==84) then
   massinusvsidnumber=209.0
else if (i==85) then
   massinusvsidnumber=210.0
else if (i==86) then
   massinusvsidnumber=222.0
else if (i==87) then
   massinusvsidnumber=223.0
else if (i==88) then
   massinusvsidnumber=226.0
else if (i==89) then
   massinusvsidnumber=227.0
else if (i==90) then
   massinusvsidnumber=232.0377
else if (i==91) then
   massinusvsidnumber=231.03588
else if (i==92) then
   massinusvsidnumber=238.02891
else if (i==93) then
   massinusvsidnumber=237.0
else if (i==94) then
   massinusvsidnumber=244.0
else if (i==95) then
   massinusvsidnumber=243.0
else if (i==96) then
   massinusvsidnumber=247.0
else if (i==97) then
   massinusvsidnumber=247.0
else if (i==98) then
   massinusvsidnumber=251.0
else if (i==99) then
   massinusvsidnumber=252.0
else if (i==100) then
   massinusvsidnumber=257.0
else if (i==101) then
   massinusvsidnumber=258.0
else if (i==102) then
   massinusvsidnumber=259.0
else if (i==103) then
   massinusvsidnumber=266.0
else if (i==201) then ! H2  In the future it should be i=104
   massinusvsidnumber=2.0_DOUBLE*1.00794_DOUBLE
else if (i==202) then ! H2O In the future it should be i=105
   massinusvsidnumber=2.0_DOUBLE*1.00794_DOUBLE+15.999_DOUBLE
else if (i==203) then ! CH4 In the future it should be i=106
   massinusvsidnumber=4.0_DOUBLE*1.00794_DOUBLE+12.0_DOUBLE
else if (i==204) then ! N2  In the future it should be i=107
   massinusvsidnumber=2.0_DOUBLE*14.007_DOUBLE
else if (i==205) then ! CO2 In the future it should be i=108
   massinusvsidnumber=12.0_DOUBLE+2.0_DOUBLE*15.999_DOUBLE
else
   massinusvsidnumber=0.0_DOUBLE
end if

end function massinusvsidnumber

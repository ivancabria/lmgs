function maxreal(a,b)
implicit none
! Parameters
include 'precision.inc'
! Function value
real(DOUBLE) :: maxreal
! Function arguments
real(DOUBLE), intent(in) :: a,b

if (a>b) then
   maxreal=a
else
   maxreal=b
end if

end function maxreal

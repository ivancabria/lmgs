function averagedistancebetweenmolecules(symbolgas)
implicit none
! Parameters
include 'precision.inc'
! Function value
real(DOUBLE) :: averagedistancebetweenmolecules ! angstrom
! Function arguments
character(3), intent(in) :: symbolgas

if (symbolgas=='H2') then ! H2
   averagedistancebetweenmolecules=2.89_DOUBLE
else
   averagedistancebetweenmolecules = 0.0_DOUBLE
end if

end function averagedistancebetweenmolecules

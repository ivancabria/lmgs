subroutine abparameterssrkeos(P,T,symbolgas,A,B)
implicit none
! Parameters
include 'precision.inc'
! Subroutine arguments
real(DOUBLE), intent(in) :: P,T
character(3), intent(in) :: symbolgas
real(DOUBLE), intent(inout) :: A,B
! Local variables
real(DOUBLE) :: omega,Pc,Tc
real(DOUBLE) :: Pr,Tr,alpha,m,sqrtalpha

call omegapctcsrkeos(symbolgas,omega,Pc,Tc)

Pr=P/Pc
Tr=T/Tc

m=0.480_DOUBLE + 1.574_DOUBLE*omega - 0.176_DOUBLE*omega*omega

sqrtalpha = 1.0_DOUBLE + m*(1.0_DOUBLE - sqrt(Tr))
alpha=sqrtalpha*sqrtalpha

A = 0.42747_DOUBLE*alpha*Pr/(Tr*Tr)
B = 0.08664_DOUBLE*Pr/Tr

end subroutine abparameterssrkeos

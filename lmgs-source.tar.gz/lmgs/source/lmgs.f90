! Langmuir Method for Gas Storage: lmgs

program lmgs
implicit none
! Parameters
include 'precision.inc'
! Program variables
integer :: i,istat,nsites
real(DOUBLE) :: areamaterialinangstrom2 ! angstrom^2
real(DOUBLE) :: areamoleculeinangstrom2 ! angstrom^2
real(DOUBLE) :: bindingenergyineV(5) ! eV/molecule
real(DOUBLE) :: densitymaterial ! kg/L
real(DOUBLE) :: diff
real(DOUBLE) :: langmuirmaxnmolecules
real(DOUBLE) :: langmuirnumberofmolecules
real(DOUBLE) :: massh2 ! kg
real(DOUBLE) :: massh2depletion ! kg
real(DOUBLE) :: massmaterial ! kg
real(DOUBLE) :: P ! the pressure in MPa
real(DOUBLE) :: Pdepletion ! the depletion pressure in MPa
real(DOUBLE) :: quotient(5) ! values between 0.0 and 1.0
real(DOUBLE) :: specificsurfacearea ! m^2/g
real(DOUBLE) :: summ
real(DOUBLE) :: T ! the temperature in K
real(DOUBLE) :: Tdepletion ! the depletion temperature in K
real(DOUBLE) :: temp
real(DOUBLE) :: totalgc ! wt. %
real(DOUBLE) :: totalvc ! kg/L
real(DOUBLE) :: totalgcdepletion ! wt. %
real(DOUBLE) :: totalvcdepletion ! kg/L
real(DOUBLE) :: volumesimulationcell
real(DOUBLE) :: usablemassh2 ! kg
real(DOUBLE) :: usablegc ! wt. %
real(DOUBLE) :: usablevc ! kg/L
character(3) :: istop
character(3) :: symbolgas

istat=0
nsites=0
areamaterialinangstrom2=0.0_DOUBLE
areamoleculeinangstrom2=0.0_DOUBLE
bindingenergyineV=0.0_DOUBLE ! eV
densitymaterial=0.0_DOUBLE ! kg/L
langmuirmaxnmolecules=0.0_DOUBLE
langmuirnumberofmolecules=0.0_DOUBLE
massh2=0.0_DOUBLE ! kg
massh2depletion=0.0_DOUBLE ! kg
massmaterial=0.0_DOUBLE ! kg
P=0.0_DOUBLE ! MPa
quotient=0.0_DOUBLE
specificsurfacearea=0.0_DOUBLE
summ=0.0_DOUBLE
T=0.0_DOUBLE ! K
temp=0.0_DOUBLE
totalgc=0.0_DOUBLE ! wt. %
totalvc=0.0_DOUBLE ! kg/L
totalgcdepletion=0.0_DOUBLE ! wt. %
totalvcdepletion=0.0_DOUBLE ! kg/L
usablegc=0.0_DOUBLE ! wt. %
usablemassh2=0.0_DOUBLE ! kg
usablevc=0.0_DOUBLE ! kg/L
istop='no'
symbolgas=''

! The storage capacities do not depend on the volume of the simulation cell
! because this volume appears in the numerator and denominator of the 
! equations and they cancel. 
! But, the number of molecules in the simulation cell depends on the 
! volume of the simulation cell.

! Read the input data
read(*,*) densitymaterial,specificsurfacearea,areamoleculeinangstrom2,&
volumesimulationcell,P,T,symbolgas
read(*,*) nsites
do i=1,nsites
   read(*,*) bindingenergyineV(i),quotient(i)
end do

! Check the quotient array
summ=0.0_DOUBLE
do i=1,nsites
   summ=summ+quotient(i)
end do

diff=abs(summ-1.0_DOUBLE)

open(20,file='tests.dat',status='unknown',iostat=istat)

write(20,100) areamoleculeinangstrom2

if (diff >= 1.0E-6_DOUBLE) then
   istop='yes'
   write(20,*) 'summ = ',summ
else
   istop='no'
end if

if (symbolgas /= "H2") then
   write(*,110) symbolgas
   istop='yes'
end if

call continueorstop(istop)

! Calculation of the mass of the material and of the area or surface 
! of the material in the simulation cell
massmaterial=densitymaterial*volumesimulationcell*1.0E-27_DOUBLE ! kg
areamaterialinangstrom2=specificsurfacearea*massmaterial*100000.0_DOUBLE*1.0E+18_DOUBLE ! angstrom^2

langmuirmaxnmolecules = areamaterialinangstrom2/areamoleculeinangstrom2

write(20,*) 'langmuirmaxnmolecules = ',langmuirmaxnmolecules

! Calculation of the total capacities at P and T
call langmuirtotalcapacities(nsites,langmuirmaxnmolecules,&
volumesimulationcell,massmaterial,P,T,bindingenergyineV,&
quotient,symbolgas,massh2,totalgc,totalvc,langmuirnumberofmolecules)

! Calculation of the total capacities at depletion P and T
Pdepletion=0.5_DOUBLE ! MPa
Tdepletion=T ! K
call langmuirtotalcapacities(nsites,langmuirmaxnmolecules,&
volumesimulationcell,massmaterial,Pdepletion,Tdepletion,bindingenergyineV,&
quotient,symbolgas,massh2depletion,totalgcdepletion,totalvcdepletion,&
temp)

! Calculation of the usable storage capacities
usablemassh2 = massh2 - massh2depletion

usablegc=100.0_DOUBLE * usablemassh2/(usablemassh2 + massmaterial) ! wt. %

usablevc=usablemassh2/(volumesimulationcell*1.0E-27_DOUBLE) ! kg/L

write(*,120) P,T,totalgc,totalvc,usablegc,usablevc,langmuirnumberofmolecules

close(20)

100 format(f18.13,1x,'angstroms^2')
110 format('The gas ',a6,' is not implemented.')
120 format(f9.3,1x,f9.3,2(1x,f9.3,1x,f12.6),1x,f12.6)

end program lmgs

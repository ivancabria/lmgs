! This subroutine calculates the roots of a polynom of third degree
! a3x^3 + a2x^2 + a1x + a0 = 0
! x^3 + ax^2 + bx + c = 0
! It calculates also the trace and the firm:
! Trace: The number of real roots
! Firm: The difference between the number of real positive
! roots and the number of real negative roots
! Firm=-4: It means that two roots are complex

subroutine rootsthirddegreepolynom(a3,a2,a1,a0,trace,firm,root)
implicit none
! Parameters
include 'precision.inc'
include 'complex.inc'
include 'pi.inc'
! Subroutine arguments
real(DOUBLE), intent(in) :: a3,a2,a1,a0
integer, intent(out) :: trace,firm
complex(DOUBLE), intent(out) :: root(3)
! Local variables
integer :: i
real(DOUBLE) :: a,b,c,q,r,s,t,v,w,d,theta,rminusd
character(3) :: istop

istop='no'

if (a3.eq.0.0_DOUBLE) then
   write(*,*) 'a3 is zero.'
   istop='yes'
end if

call continueorstop(istop)

a=a2/a3
b=a1/a3
c=a0/a3
q=(3.0_DOUBLE*b-(a**2))/9.0_DOUBLE
r=(9.0_DOUBLE*a*b-27.0_DOUBLE*c-2.0_DOUBLE*(a**3))/54.0_DOUBLE
d=(q**3)+(r**2)

if (d.gt.0.0_DOUBLE) then
   s=(r+sqrt(d))**(1.0_DOUBLE/3.0_DOUBLE)

   rminusd=r-sqrt(d)
   if (rminusd<0.0_DOUBLE) then
      t=-abs(rminusd)**(1.0_DOUBLE/3.0_DOUBLE)
   else
      t=rminusd**(1.0_DOUBLE/3.0_DOUBLE)
   end if

   root(1)=s+t-(a/3.0_DOUBLE)
   v=-((s+t)/2.0_DOUBLE)-(a/3.0_DOUBLE)
   w=sqrt(3.0_DOUBLE)*(s-t)/2.0_DOUBLE
   root(2)=v+CI*w
   root(3)=v-CI*w
   trace=1
else if (d.eq.0.0_DOUBLE.and.q.ne.0.0_DOUBLE) then
   s=(r/abs(r))*(abs(r)**(1.0_DOUBLE/3.0_DOUBLE))
   t=s
   root(1)=2.0_DOUBLE*s-(a/3.0_DOUBLE)
   root(2)=-s-(a/3.0_DOUBLE)
   root(3)=root(2)
   trace=3
else if (d.eq.0.0_DOUBLE.and.q.eq.0.0_DOUBLE) then
   if (-c<0.0_DOUBLE) then
      root(1)=-(abs(c))**(-1.0_DOUBLE/3.0_DOUBLE)
   else
      root(1)=(-c)**(-1.0_DOUBLE/3.0_DOUBLE)
   end if
   root(2)=root(1)
   root(3)=root(1)
   trace=3
else if (d.lt.0.0_DOUBLE) then
   theta=acos(r/sqrt(-(q**3)))
   root(1)=2.0_DOUBLE*sqrt(-q)*cos(theta/3.0_DOUBLE)-(a/3.0_DOUBLE)
   root(2)=-(a/3.0_DOUBLE)+&
   2.0_DOUBLE*sqrt(-q)*cos((theta+2.0_DOUBLE*PI)/3.0_DOUBLE)
   root(3)=-(a/3.0_DOUBLE)+&
   2.0_DOUBLE*sqrt(-q)*cos((theta+4.0_DOUBLE*PI)/3.0_DOUBLE)
   trace=3
end if

if (trace.eq.3) then
   firm=0
   do i=1,3
      if (real(root(i),DOUBLE).ge.0.0_DOUBLE) firm=firm+1
      if (real(root(i),DOUBLE).lt.0.0_DOUBLE) firm=firm-1
   end do
else
   firm=-4 ! Two roots are complex
end if

end subroutine rootsthirddegreepolynom

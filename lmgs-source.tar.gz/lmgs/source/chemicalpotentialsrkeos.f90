! chemicalpotentialsrkeos is in rydbergs/molecule

! lth3 is the thermal de Broglie wavelength to the power of three in angstrom^3
! P is the pressure in MPa
! T is the temperature in K
! fi is the fugacity coefficient; fi = f/P; f is the fugacity

! chemical potential = mu = kBT log( fi Plth^3/kBT ) = kBT [ log(Plth^3/kBT) + log(fi) ]

function chemicalpotentialsrkeos(P,T,symbolgas)
implicit none
! Parameters
include 'precision.inc'
include 'kb.inc'
include 'evshartree.inc'
include 'joulesev.inc'
include 'kbinjoulesperk.inc'
! Function value
real(DOUBLE) :: chemicalpotentialsrkeos ! rydbergs/molecule
! Function arguments
real(DOUBLE), intent(in) :: P,T
character(3), intent(in) :: symbolgas
! Local variables
real(DOUBLE) :: logfi,lth,lth3
! Functions
real(DOUBLE) :: logfugacitycoefficientsrkeos,thermaldeBrogliewavelength

! lth3*P*1.e-24 is in Joules (1 Joule = 1 m^3 * Pa)
! KBINJOULESPERK*T is also in Joules 
! KB is in hartrees/K
! 1 hartree = 2 rydbergs
! 2*KB*T is in rydbergs/molecule
! Therefore, chemicalpotentialsrkeos is in rydbergs/molecule

! Thermal De Broglie wavelength of a molecule of the gas
lth=thermaldeBrogliewavelength(T,symbolgas) ! angstroms

lth3=lth*lth*lth

logfi = logfugacitycoefficientsrkeos(P,T,symbolgas) ! dimensionless

chemicalpotentialsrkeos=2.0_DOUBLE*KB*T*( log(lth3*P*1.e-24_DOUBLE/(KBINJOULESPERK*T)) + &
logfi ) ! rydbergs/molecule

end function chemicalpotentialsrkeos

! thermaldeBrogliewavelength is in angstroms

function thermaldeBrogliewavelength(Temperature,symbolgas)
implicit none
! Parameters
include 'precision.inc'
include 'pi.inc'
include 'hbar.inc'
include 'kb.inc'
include 'a0.inc'
! Function value
real(DOUBLE) :: thermaldeBrogliewavelength ! angstroms
! Function arguments
real(DOUBLE), intent(in) :: Temperature
character(3), intent(in) :: symbolgas
! Local variables
real(DOUBLE) :: mass
character(30) :: units
! Functions
real(DOUBLE) :: massmolecule

! Temperature in Kelvins
! KB in hartrees/K
! HBAR in atomic units

! mass in atomic units (In atomic units, the mass of the electron is 1)
units='atomicunitsofmass'
mass=massmolecule(symbolgas,units) ! atomic units of mass

! sqrt((2.0_DOUBLE*PI*HBAR*HBAR)/(mass*KB*Temperature)) is in bohrs
! A0*sqrt((2.0_DOUBLE*PI*HBAR*HBAR)/(mass*KB*Temperature)) is in angstroms

if (mass>0.0_DOUBLE) then
   thermaldeBrogliewavelength=A0*sqrt((2.0_DOUBLE*PI*HBAR*HBAR)/(mass*KB*Temperature)) ! angstroms
else
   thermaldeBrogliewavelength=0.0_DOUBLE ! angstroms
end if

end function thermaldeBrogliewavelength

subroutine continueorstop(istop)
implicit none
! Parameters
#ifdef mpi
include 'mpif.h'
#endif
! Subroutine arguments
character(3), intent(in) :: istop
! Local variables
#ifdef mpi
integer :: error
#endif
integer :: time_array(8),year
character(2) :: dayc,hourc,minutec,secondc
character(3) :: month3c
character(4) :: yearc
character(32) :: host
! Functions
character(32) :: hostname

if (istop=='yes') then

   time_array=0
   year=0
   dayc=''
   hourc=''
   minutec=''
   secondc=''
   month3c=''
   yearc=''

   call timecomponents(time_array,year,dayc,hourc,minutec,secondc,&
   month3c,yearc)

   host=hostname()
   write(*,100) month3c,dayc,yearc,hourc,minutec,secondc,host

#ifdef mpi
   call MPI_Abort(MPI_COMM_WORLD,-1,error)
   call MPI_Finalize(error)
#else
   stop
#endif

end if

100 format(/,'Run stopped on ',a3,' ',a2,' ',a4,' ',a2,':',a2,':',a2,&
' at ',a32)

end subroutine continueorstop
